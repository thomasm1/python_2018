This directory contains ONLY the django project, not the virtual environment.

The reason for this is that virtual environments cannot be moved or ported between systems in a reliable way.
