(function () {
    'use strict';

    angular.module('scrumboard.demo', ['ngRoute']);

}());
